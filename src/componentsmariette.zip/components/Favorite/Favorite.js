import React ,{useState} from 'react';
import { View , StyleSheet,TouchableOpacity,Image} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const Favorite = () => {
    
    const heartEmpty='https://www.citypng.com/public/uploads/preview/-51610329431xv3s3v3d9v.png';
    const heartFill='https://www.pngitem.com/pimgs/m/307-3070057_red-heart-outline-png-transparent-png.png';
    const [defaultFavorite, setdefaultFavorite] =React.useState(false);
    const [favorite, setFavorite] = useState([1])
return(
    <View style={styles.heartBar}>
            
                {favorite.map((item, key) => {
                    return (
                        <TouchableOpacity
                            // activeOpacity={0.7}
                            key={item}
                            onPress={() => setdefaultFavorite(item=>!item)}
                            
                        >
                            <Image
                                style={styles.heartImg}
                                source={
                                    item <= defaultFavorite ? { uri: heartFill } : { uri: heartEmpty }  
                                    // <Icon name="heart-outline" size={23} color="#000"/> 
                                }
                                
                            />
                        
                        </TouchableOpacity>
                        
                    )

                })
                }

            </View>
            
        );
    
        
    };
   
    const styles = StyleSheet.create({
        heartBar:{
            // justifyContent:'center',
            flexDirection:'row',
            marginTop:10,
            marginRight:10,
        },
        heartImg:{
            width:30,
            height:30,
            resizeMode:'cover',
            marginLeft: 20,
            marginBottom:30,
            padding:10,
        },
        
    })
export default Favorite ;