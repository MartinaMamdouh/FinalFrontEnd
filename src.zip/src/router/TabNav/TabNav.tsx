import React from "react";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from "../../screens/HomeScreen";
import Icon from 'react-native-vector-icons/Ionicons';
import SignInScreen from "../../screens/SignInScreen";


const Tab = createBottomTabNavigator();
const TabNav = () => {
    return (
        <NavigationContainer >
        <Tab.Navigator 
            initialRouteName='HomeScreen'
            screenOptions={({ route }) => ({
                headerShown: false,
                tabBarStyle: { elevation: 0, borderTopWidth: 0,marginBottom:0, backgroundColor: 'red' },
                tabBarIcon: ({ focused, iconColor, iconName }) => {
                    if (route.name === 'HomeScreen') {
                        iconColor = focused ? '#E27A94' : '#ff00ff'
                        iconName = 'home-outline'
                    }
                    else if (route.name === 'Directions') {
                        iconColor = focused ? '#E27A94' : '#ff00ff'
                        iconName = 'heart-outline'
                    }
                    else if (route.name === 'Bookmarks') {
                        iconColor = focused ? '#E27A94' : '#ff00ff'
                        iconName = 'cart-outline'
                    }
                    else {
                        iconColor = focused ? '#E27A94' : '#ff00ff'
                        iconName = 'person-outline'
                    }
                    return <Icon name={iconName} size={25} color={iconColor} />;
                },
                tabBarShowLabel: false,
            })
            }

        >
            <Tab.Screen name="HomeScreen" component={HomeScreen} />
            <Tab.Screen name="Directions" component={SignInScreen} />
            <Tab.Screen name="Bookmarks" component={HomeScreen} />
            <Tab.Screen name="Profile" component={HomeScreen} />

        </Tab.Navigator>
        </NavigationContainer>


    )
}
// const styles=StyleSheet.create({
//     container:{
//         flexDirection:'row',
//         marginBottom:10,
//     },
// });

export default TabNav;